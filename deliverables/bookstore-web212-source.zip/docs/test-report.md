# Test Report — Giai đoạn UI

## Môi trường

- PHP CLI 8.4.26.
- Apache/Laragon local.
- URL kiểm thử: `http://localhost/`.
- Thời điểm: 2026-11-04.

## Kết quả

| Nhóm | Kết quả | Bằng chứng |
|---|---|---|
| PHP syntax | PASS | 53/53 file PHP qua `php -l` |
| Route shop/admin | PASS | Route shop trả 200; route admin đã đăng nhập trả 200 |
| 404 | PASS | `/khong-ton-tai` trả HTTP 404 |
| Asset | PASS | CSS, JS, SVG trả HTTP 200 |
| Internal path | PASS | `/app/`, `/config/`, `/storage/`, `/.env` trả 404 |
| Responsive probe | PASS | Playwright probe không có mục Hỏng, không overflow |
| Browser console | NOT RUN | Chưa có yêu cầu kiểm tra console riêng |
| Contrast thủ công | NOT RUN | Chưa đo bằng công cụ WCAG chuyên dụng |
| Performance Core Web Vitals | NOT RUN | Chưa có hosting/đo thực tế |
| PDO connection | PASS | Kết nối MySQL Laragon |
| Seed data | PASS | 8 categories, 40 books |
| CSRF validation | PASS | Form đăng ký và cart |
| Session cart | PASS | Thêm/xóa sản phẩm qua HTTP smoke test |
| Order transaction | PASS | Tạo order, order item, trừ tồn kho rồi cleanup test |
| Admin authorization | PASS | Route admin chưa đăng nhập trả 403 |
| Admin login smoke | PASS | Đăng nhập CSRF qua HTTP, mở 5 màn hình admin |

## Route đã kiểm tra

`/`, `/books`, `/books/nha-gia-kim`, `/categories/van-hoc`, `/cart`, `/checkout`, `/login`, `/register`, `/account`, `/orders`, `/about`, `/contact`, `/admin`, `/admin/books`, `/admin/books/create`, `/admin/books/1/edit`, `/admin/categories`, `/admin/orders`, `/admin/customers`, `/khong-ton-tai`.

## Giới hạn

Đây là test local cho nền tảng và chức năng cơ bản. Chưa kiểm tra thanh toán online, email, tải cao, hosting thật hoặc đo Core Web Vitals. Mật khẩu Admin demo local không được lưu trong tài liệu hoặc mã nguồn.
