<?php

declare(strict_types=1);

return [
    'name' => 'Nhà sách Mộc Bản',
    'base_url' => '/',
    'production' => true,
];
