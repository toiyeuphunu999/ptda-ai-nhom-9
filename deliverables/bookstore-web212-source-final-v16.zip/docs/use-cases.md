# Use Cases — Website bán sách Mộc Bản

## UC-01: Xem danh sách sách

- Actor: Khách vãng lai.
- Tiền điều kiện: Không yêu cầu.
- Luồng chính: Mở `/books` → hệ thống hiển thị lưới sách → người dùng chọn một sách.
- Kết quả hiện tại: UI hiển thị dữ liệu từ MySQL qua PDO.
- Ngoại lệ: Không có sách → hiển thị empty state.

## UC-02: Xem chi tiết sách

- Actor: Khách vãng lai.
- Luồng chính: Chọn card sách → mở `/books/{slug}` → xem bìa, tên, tác giả, giá, mô tả và tồn kho mẫu.
- Kết quả hiện tại: Người dùng có thể thêm sách vào giỏ sau khi xác thực CSRF.

## UC-03: Tìm kiếm sách

- Actor: Khách vãng lai.
- Luồng chính: Nhập từ khóa → gửi GET `/search?q=...` → truy vấn sách qua PDO.
- Ngoại lệ: Không có kết quả → hiển thị hướng dẫn tìm lại.
- Mở rộng: Danh sách sách hỗ trợ lọc theo danh mục, tác giả, khoảng giá và sắp xếp theo giá hoặc thời gian cập nhật.
- Giới hạn: Chưa có bộ lọc nâng cao.

## UC-04: Đăng ký/đăng nhập

- Actor: Khách hàng.
- Luồng chính: Gửi form hợp lệ → kiểm tra CSRF/validation → hash hoặc verify mật khẩu → tạo session.
- Ngoại lệ: Dữ liệu sai → hiển thị lỗi, không tạo session.

## UC-05: Quản lý giỏ hàng và thanh toán

- Actor: Khách hàng.
- Luồng chính: Chọn sách → Session cart → kiểm tra tồn kho → nhập địa chỉ → tạo đơn COD.
- Trạng thái: Đã triển khai transaction đơn hàng; chưa có thanh toán online.

## UC-06: Quản trị sách

- Actor: Quản trị viên.
- Luồng chính: Admin mở `/admin/books` → tạo/sửa/xóa → CSRF và validation → cập nhật database.
- Trạng thái: CRUD cơ bản đã triển khai.

## UC-07: Quản lý đơn hàng/khách hàng

- Actor: Quản trị viên.
- Luồng chính: Admin mở bảng đơn hàng/khách hàng → xem dữ liệu từ database; admin có thể cập nhật trạng thái đơn.
- Trạng thái: Đã có bảo vệ quyền và đọc dữ liệu thật.
