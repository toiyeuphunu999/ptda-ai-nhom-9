# SRS — Website bán sách trực tuyến Mộc Bản

## 1. Tổng quan

Đây là tài liệu đặc tả yêu cầu phần mềm cho đồ án WEB212 — Phát triển dự án với AI. Sản phẩm là website bán sách trực tuyến, giao diện tiếng Việt, tiền tệ VNĐ, triển khai dự kiến trên PHP Shared Hosting/Apache.

## 2. Mục tiêu và phạm vi

Mục tiêu là xây dựng luồng rõ ràng: trang chủ → danh sách/danh mục → chi tiết sách → giỏ hàng → thanh toán. Bản hiện tại đã có UI, PDO và các nghiệp vụ cơ bản.

Đã có trong bản hiện tại:

- Trang chủ, danh sách sách, chi tiết sách, danh mục, tìm kiếm trình bày.
- Giỏ hàng Session, checkout COD, đăng nhập, đăng ký, tài khoản, lịch sử đơn hàng.
- Khu vực quản trị có bảo vệ: tổng quan, CRUD sách/danh mục, đơn hàng, khách hàng.
- PHP OOP/MVC, router tập trung, `.htaccess`, dữ liệu 40 sách và 8 danh mục.

Chưa có:

- Thanh toán, email, voucher, API nghiệp vụ hoặc AI recommendation.
- Biến thể sách. Cách xử lý bìa mềm/bìa cứng hoặc phiên bản sách: **PENDING TEACHER CONFIRMATION**.

## 3. Người dùng

- Khách vãng lai: xem, tìm và đọc thông tin sách.
- Khách hàng: có tài khoản, giỏ hàng, đặt hàng COD và lịch sử mua.
- Quản trị viên: quản lý sách, danh mục, đơn hàng và khách hàng.

## 4. Yêu cầu chức năng

| Mã | Yêu cầu | Trạng thái |
|---|---|---|
| FR-01 | Xem trang chủ và danh mục | Đã có |
| FR-02 | Xem danh sách và chi tiết sách | Đã có |
| FR-03 | Tìm kiếm sách | Đã có PDO |
| FR-04 | Đăng ký/đăng nhập | Đã có |
| FR-05 | Quản lý giỏ hàng bằng Session | Đã có |
| FR-06 | Tạo đơn hàng COD | Đã có transaction |
| FR-07 | Quản trị sách/danh mục | CRUD cơ bản đã có |
| FR-08 | Phân quyền khách hàng/quản trị viên | Đã có bảo vệ admin |

## 5. Yêu cầu phi chức năng

- Backend PHP 8.x, OOP, kiến trúc MVC tự xây dựng.
- Database dùng MySQL + PDO Prepared Statements; không dùng `mysqli_*`.
- Giao diện responsive từ 320px, semantic HTML và accessibility cơ bản.
- Production đặt DocumentRoot vào `public/`, không công khai `app/`, `config/`, `storage/`.
- Dữ liệu hiển thị phải escape theo ngữ cảnh HTML.

## 6. Dữ liệu khởi tạo

Tám danh mục: Văn học, Kinh tế, Kỹ năng sống, Công nghệ thông tin, Truyện tranh, Thiếu nhi, Ngoại ngữ, Sách giáo khoa. Có 40 sách khởi tạo, 5 sách mỗi danh mục. Giá, tồn kho và ảnh được quản lý từ catalogue của hệ thống.

## 7. Tiêu chí nghiệm thu giai đoạn UI

- Route hợp lệ trả `200`, route không tồn tại trả `404` thật.
- CSS, JavaScript và placeholder trả `200`.
- Không có authentication/CRUD/thanh toán giả.
- Không có gradient, glassmorphism, neon hoặc bo góc trang trí.
- Responsive probe không phát hiện overflow hoặc chồng lấn.
