# Nhà sách Mộc Bản — WEB212

Website bán sách trực tuyến cho đồ án WEB212, chạy local trên PHP/Apache/MySQL.

## Phạm vi hiện tại

- PHP 8.x, OOP, MVC và routing tập trung tại `public/index.php`.
- MySQL Laragon database `bookstore_web212`, PDO Prepared Statements và schema trong `database/schema.sql`.
- 8 danh mục và 40 sách mẫu trong `database/seed.sql`.
- Đăng ký/đăng nhập, password hash, session cookie, CSRF và bảo vệ admin.
- CRUD sách/danh mục cơ bản, giỏ hàng Session và đặt hàng COD.
- Đơn hàng dùng transaction và khóa tồn kho trong lúc tạo đơn.
- Chưa có thanh toán online, email, voucher, API nghiệp vụ hoặc biến thể sách.
- Tạo Admin demo bằng `php tools/create_admin.php`; không có credential mặc định trong source.

## Chạy local

Đặt DocumentRoot của Apache vào thư mục `public/`. Khi dùng PHP built-in server:

```text
php -S localhost:8000 -t public
```

Sau đó mở `http://localhost:8000/`.

## Route chính

`/`, `/books`, `/books/{slug}`, `/categories/{slug}`, `/search`, `/cart`, `/checkout`, `/login`, `/register`, `/account`, `/orders`, `/about`, `/contact` và nhóm `/admin`.

Ảnh bìa hiện dùng placeholder local. Sách, khách hàng và đơn hàng trong database Laragon là dữ liệu môi trường phát triển.
