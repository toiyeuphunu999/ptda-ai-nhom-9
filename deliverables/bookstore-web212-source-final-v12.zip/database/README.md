# Database

Schema, seed và lớp kết nối PDO nằm trong `schema.sql`, `seed.sql`, `config/database.php` và `app/Core/Database.php`. Môi trường Laragon local hiện dùng database `bookstore_web212`.

Các bảng gồm `users`, `categories`, `books`, `orders`, `order_items`. Khóa chính dùng cột `id`; `books.category_id` tham chiếu `categories.id`; `orders.user_id` tham chiếu `users.id`; `order_items.order_id` và `order_items.book_id` tham chiếu đơn hàng và sách.

Để khởi tạo local, chạy lần lượt `schema.sql` rồi `seed.sql`. Không chạy lại seed trên môi trường có dữ liệu thật nếu chưa kiểm tra nội dung.
