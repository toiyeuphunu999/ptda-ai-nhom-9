# ERD và thiết kế dữ liệu

Mô hình dưới đây đã được triển khai trong `database/schema.sql` và dùng bởi các model PDO. `database/seed.sql` cung cấp dữ liệu demo local.

```text
users 1 ───< orders 1 ───< order_items >─── 1 books >─── 1 categories
```

## Các bảng đã triển khai

### users

- `id` — PK, số nguyên.
- `name`, `email`, `password_hash`, `role`, `created_at`, `updated_at`.
- `email` cần unique; mật khẩu lưu bằng hash khi triển khai.

### categories

- `id` — PK.
- `name`, `slug`, `description`, `created_at`, `updated_at`.
- `slug` cần unique.

### books

- `id` — PK.
- `category_id` — FK tới `categories.id`.
- `title`, `slug`, `author`, `publisher`, `price`, `original_price`, `description`, `cover`, `stock_quantity`, `status`, timestamps.

### orders

- `id` — PK.
- `user_id` — FK tới `users.id`.
- `order_code`, `status`, `subtotal`, `shipping_fee`, `total`, `shipping_name`, `shipping_phone`, `shipping_address`, timestamps.

### order_items

- `id` — PK.
- `order_id` — FK tới `orders.id`.
- `book_id` — FK tới `books.id`.
- `book_title`, `unit_price`, `quantity`, `line_total`.

## Chuẩn hóa

- 1NF: mỗi cột chứa một giá trị nguyên tử; sản phẩm trong đơn nằm ở `order_items`.
- 2NF: thuộc tính của sách, người dùng và danh mục không lặp trong bảng đơn hàng; dòng chi tiết phụ thuộc vào bản ghi chi tiết.
- 3NF: thông tin danh mục, người dùng và sách tách riêng, không lưu thuộc tính phụ thuộc bắc cầu trong `orders`.

## Lưu ý nghiệp vụ

Sách chưa áp dụng size/màu. Cách xử lý biến thể bìa mềm/bìa cứng hoặc phiên bản sách là **PENDING TEACHER CONFIRMATION**.
