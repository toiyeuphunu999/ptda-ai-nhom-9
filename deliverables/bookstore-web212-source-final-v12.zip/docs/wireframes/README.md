# Wireframes

## Phạm vi

Wireframe giai đoạn này mô tả bố cục các nhóm màn hình chính; bản UI thật nằm trong `app/Views/` và đã được kiểm tra responsive.

## Shop

Wireframe trực quan: [`shop-overview.svg`](shop-overview.svg).

```text
Header: logo | điều hướng | tìm kiếm | giỏ hàng | tài khoản
Trang chủ: giới thiệu ngắn → danh mục → lưới sách
Danh sách: breadcrumb → tiêu đề → lưới Book Card
Chi tiết: breadcrumb → bìa sách | thông tin và giá
Form: tiêu đề → trường nhập → nút/trạng thái minh họa
Footer: thương hiệu → hỗ trợ → thông tin demo
```

## Admin

Wireframe trực quan: [`admin-overview.svg`](admin-overview.svg).

```text
Sidebar: tổng quan / sách / danh mục / đơn hàng / khách hàng
Header: cấp khu vực → tiêu đề → ghi chú môi trường demo
Nội dung: thẻ tổng quan, bảng dữ liệu hoặc empty state
```

Các form nghiệp vụ chính đã nối với backend local; form liên hệ vẫn là giao diện minh họa và không gửi dữ liệu. Bản vẽ hình ảnh chính thức có thể bổ sung sau khi nhóm chốt công cụ và format nộp với giảng viên.
