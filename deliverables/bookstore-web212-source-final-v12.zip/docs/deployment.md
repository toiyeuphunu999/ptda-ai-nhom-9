# Hướng dẫn triển khai

## Local với Laragon

1. Đặt mã nguồn trong thư mục Laragon, ví dụ `C:\laragon\www`.
2. Đặt Apache DocumentRoot vào thư mục `public` của dự án.
3. Bật Apache trong Laragon.
4. Mở `http://localhost/`.
5. Kiểm tra route `/`, `/books` và `/khong-ton-tai`.

## Khởi tạo database

Trong MySQL Laragon, tạo database `bookstore_web212`, sau đó chạy lần lượt `database/schema.sql` và `database/seed.sql`. Không chạy lại seed trên production nếu chưa kiểm tra dữ liệu hiện có.

## Apache Shared Hosting/cPanel

- Nếu hosting cho phép, đặt DocumentRoot vào thư mục `public/`.
- Nếu không đổi được DocumentRoot, phải lập phương án triển khai riêng và kiểm tra lại quyền truy cập trước khi dùng; không tự ý chuyển toàn bộ thư mục nội bộ ra public.
- Bật URL rewriting và giữ `.htaccess` trong `public/`.
- Không upload `.env` thật, credential, log hoặc thư mục dependency không cần thiết.
- Cấu hình PHP 8.x và tạo database riêng ở giai đoạn chức năng.

## Tạo Admin demo

Không có mật khẩu Admin mặc định trong mã nguồn. Sau khi tạo database, chạy lệnh tại thư mục project:

```text
php tools/create_admin.php
```

Nhập tên, email và mật khẩu riêng cho môi trường demo. Không commit credential vào Git và không dùng mật khẩu demo ở production.

## Production đã triển khai

- Live URL: `https://nhom9.khag.tech/`
- Admin demo email: `admin@nhom9.com`
- Mật khẩu: bàn giao riêng, không lưu trong repository hoặc tài liệu công khai.
- Kiểm tra HTTP gần nhất: trang chủ, route sách/danh mục/tìm kiếm, asset, 404 và 5 màn hình Admin đều đạt.

## Còn phụ thuộc nghiệp vụ

Thanh toán online, email, voucher và biến thể sách chưa triển khai. SQL đã có trong `database/schema.sql` và `database/seed.sql`.
