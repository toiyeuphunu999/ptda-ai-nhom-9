<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Database;
use App\Models\Book;
use App\Models\Category;

final class BookController extends Controller
{
    private function bookModel(): Book { return new Book(new Database(require dirname(__DIR__, 2) . '/config/database.php')); }
    private function categoryModel(): Category { return new Category(new Database(require dirname(__DIR__, 2) . '/config/database.php')); }

    public function index(): void { $this->view->render('shop/books', ['title'=>'Tất cả sách','books'=>$this->bookModel()->published()]); }
    public function detail(string $slug): void {
        $book = $this->bookModel()->findBySlug($slug);
        if (!$book) { http_response_code(404); $this->view->render('errors/404', ['title'=>'Không tìm thấy sách']); return; }
        $this->view->render('shop/book_detail', ['title'=>$book['title'],'book'=>$book]);
    }
    public function category(string $slug): void {
        $books = $this->bookModel()->byCategory($slug);
        $category = $this->categoryModel()->findBySlug($slug);
        $this->view->render('shop/category', ['title'=>$category['name'] ?? 'Danh mục','books'=>$books,'category'=>$category ?: null]);
    }
    public function search(): void {
        $query = trim((string)($_GET['q'] ?? ''));
        $books = $query === '' ? $this->bookModel()->published() : $this->bookModel()->search($query);
        $this->view->render('shop/search', ['title'=>'Tìm kiếm','books'=>$books,'query'=>$query]);
    }
}
