<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Csrf;
use App\Core\Database;
use App\Core\Session;
use App\Models\Book;
use App\Models\Category;
use App\Models\Order;
use App\Models\User;
use RuntimeException;
use Throwable;

final class AdminPageController extends Controller
{
    private function database(): Database { return new Database(require dirname(__DIR__, 2) . '/config/database.php'); }
    private function authorize(): void
    {
        Session::start();
        $user = Session::get('user');
        if (!is_array($user) || ($user['role'] ?? '') !== 'admin') {
            http_response_code(403);
            $this->view->render('errors/404', ['title'=>'Không có quyền truy cập']);
            exit;
        }
    }
    public function dashboard(): void { $this->authorize(); $database = $this->database(); $this->view->render('admin/dashboard', ['title'=>'Tổng quan','bookCount'=>(new Book($database))->countAll(),'categoryCount'=>(new Category($database))->countAll(),'orderCount'=>(new Order($database))->countAll(),'customerCount'=>(new User($database))->countAll()], 'admin'); }
    public function books(): void { $this->authorize(); $this->view->render('admin/books', ['title'=>'Quản lý sách','books'=>(new Book($this->database()))->allForAdmin()], 'admin'); }
    public function bookCreate(): void { $this->authorize(); $this->view->render('admin/book_form', ['title'=>'Thêm sách','categories'=>(new Category($this->database()))->all()], 'admin'); }
    public function bookEdit(string $id): void { $this->authorize(); $this->view->render('admin/book_form', ['title'=>'Chỉnh sửa sách','book'=>(new Book($this->database()))->findById((int)$id),'categories'=>(new Category($this->database()))->all()], 'admin'); }
    public function categories(): void { $this->authorize(); $this->view->render('admin/categories', ['title'=>'Danh mục','categories'=>(new Category($this->database()))->all()], 'admin'); }
    public function orders(): void { $this->authorize(); $this->view->render('admin/orders', ['title'=>'Đơn hàng','orders'=>(new Order($this->database()))->allForAdmin()], 'admin'); }
    public function customers(): void { $this->authorize(); $this->view->render('admin/customers', ['title'=>'Khách hàng','customers'=>(new User($this->database()))->allForAdmin()], 'admin'); }

    private function bookData(): array
    {
        $title = trim((string)($_POST['title'] ?? ''));
        $slug = trim((string)($_POST['slug'] ?? ''));
        $author = trim((string)($_POST['author'] ?? ''));
        $price = (int)($_POST['price'] ?? 0);
        $original = trim((string)($_POST['original_price'] ?? ''));
        $categoryId = (int)($_POST['category_id'] ?? 0);
        if ($title === '' || $slug === '' || $author === '' || $categoryId < 1 || $price < 0 || ($original !== '' && (int)$original < $price)) {
            throw new RuntimeException('Vui lòng kiểm tra tên, slug, tác giả, danh mục và giá sách.');
        }
        return ['category_id'=>$categoryId,'title'=>$title,'slug'=>$slug,'author'=>$author,'publisher'=>trim((string)($_POST['publisher'] ?? '')) ?: null,'price'=>$price,'original_price'=>$original === '' ? null : (int)$original,'description'=>trim((string)($_POST['description'] ?? '')) ?: null,'stock_quantity'=>max(0,(int)($_POST['stock_quantity'] ?? 0)),'status'=>in_array($_POST['status'] ?? 'draft', ['draft','published','hidden'], true) ? $_POST['status'] : 'draft'];
    }
    public function bookStore(): void { $this->authorize(); try { Csrf::verify($_POST['_csrf'] ?? null); (new Book($this->database()))->create($this->bookData()); header('Location: /admin/books'); } catch (Throwable $e) { http_response_code(422); $this->view->render('admin/book_form', ['title'=>'Thêm sách','error'=>$e->getMessage(),'categories'=>(new Category($this->database()))->all()], 'admin'); } }
    public function bookUpdate(string $id): void { $this->authorize(); try { Csrf::verify($_POST['_csrf'] ?? null); (new Book($this->database()))->update((int)$id, $this->bookData()); header('Location: /admin/books'); } catch (Throwable $e) { http_response_code(422); $this->view->render('admin/book_form', ['title'=>'Chỉnh sửa sách','error'=>$e->getMessage(),'book'=>(new Book($this->database()))->findById((int)$id),'categories'=>(new Category($this->database()))->all()], 'admin'); } }
    public function bookDelete(string $id): void { $this->authorize(); Csrf::verify($_POST['_csrf'] ?? null); (new Book($this->database()))->delete((int)$id); header('Location: /admin/books'); }

    private function categoryData(): array
    {
        $name = trim((string)($_POST['name'] ?? ''));
        $slug = trim((string)($_POST['slug'] ?? ''));
        if ($name === '' || !preg_match('/^[a-z0-9]+(?:-[a-z0-9]+)*$/', $slug)) {
            throw new RuntimeException('Tên danh mục không được trống và slug chỉ dùng chữ thường, số, dấu gạch ngang.');
        }
        return [$name, $slug, trim((string)($_POST['description'] ?? '')) ?: null];
    }

    public function categoryStore(): void
    {
        $this->authorize();
        try {
            Csrf::verify($_POST['_csrf'] ?? null);
            [$name, $slug, $description] = $this->categoryData();
            (new Category($this->database()))->create($name, $slug, $description);
            header('Location: /admin/categories');
        } catch (Throwable $exception) {
            http_response_code(422);
            $this->view->render('admin/categories', ['title'=>'Danh mục','error'=>$exception->getMessage(),'categories'=>(new Category($this->database()))->all()], 'admin');
        }
    }

    public function categoryUpdate(string $id): void
    {
        $this->authorize();
        try {
            Csrf::verify($_POST['_csrf'] ?? null);
            [$name, $slug, $description] = $this->categoryData();
            (new Category($this->database()))->update((int)$id, $name, $slug, $description);
            header('Location: /admin/categories');
        } catch (Throwable $exception) {
            http_response_code(422);
            $this->view->render('admin/categories', ['title'=>'Danh mục','error'=>$exception->getMessage(),'categories'=>(new Category($this->database()))->all()], 'admin');
        }
    }

    public function categoryDelete(string $id): void
    {
        $this->authorize();
        Csrf::verify($_POST['_csrf'] ?? null);
        (new Category($this->database()))->delete((int)$id);
        header('Location: /admin/categories');
    }

    public function orderStatus(string $id): void
    {
        $this->authorize();
        Csrf::verify($_POST['_csrf'] ?? null);
        (new Order($this->database()))->updateStatus((int)$id, (string)($_POST['status'] ?? ''));
        header('Location: /admin/orders');
    }
}
