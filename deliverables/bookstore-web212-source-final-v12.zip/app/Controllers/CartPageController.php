<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Csrf;
use App\Core\Database;
use App\Core\Session;
use App\Models\Book;
use App\Models\Order;
use Throwable;

final class CartPageController extends Controller
{
    private function books(): Book { return new Book(new Database(require dirname(__DIR__, 2) . '/config/database.php')); }

    private function cartItems(): array
    {
        $cart = Session::get('cart', []);
        $items = [];
        foreach ($cart as $bookId => $quantity) {
            $book = $this->books()->findById((int)$bookId);
            if (!$book || $book['status'] !== 'published') {
                continue;
            }
            $items[] = ['book'=>$book, 'quantity'=>min((int)$quantity, (int)$book['stock_quantity'])];
        }
        return array_values(array_filter($items, fn(array $item): bool => $item['quantity'] > 0));
    }

    public function cart(): void { Session::start(); $this->view->render('shop/cart', ['title'=>'Giỏ hàng','items'=>$this->cartItems()]); }
    public function checkout(): void
    {
        Session::start();
        $user = Session::get('user');
        if (!is_array($user)) { header('Location: /login'); return; }
        $this->view->render('shop/checkout', ['title'=>'Thanh toán']);
    }

    public function placeOrder(): void
    {
        Session::start();
        $user = Session::get('user');
        if (!is_array($user)) { header('Location: /login'); return; }
        try {
            Csrf::verify($_POST['_csrf'] ?? null);
            $name = trim((string)($_POST['shipping_name'] ?? ''));
            $phone = trim((string)($_POST['shipping_phone'] ?? ''));
            $address = trim((string)($_POST['shipping_address'] ?? ''));
            if ($name === '' || $phone === '' || $address === '') throw new \RuntimeException('Vui lòng nhập đủ thông tin nhận hàng.');
            $items = array_map(fn(array $item): array => ['book_id'=>(int)$item['book']['id'], 'quantity'=>(int)$item['quantity']], $this->cartItems());
            $code = (new Order(new Database(require dirname(__DIR__, 2) . '/config/database.php')))->createFromCart((int)$user['id'], $items, $name, $phone, $address);
            Session::put('cart', []);
            header('Location: /orders?created=' . urlencode($code));
        } catch (Throwable $exception) {
            http_response_code(422);
            $this->view->render('shop/checkout', ['title'=>'Thanh toán','error'=>$exception->getMessage()]);
        }
    }

    public function orderHistory(): void
    {
        Session::start();
        $user = Session::get('user');
        if (!is_array($user)) { header('Location: /login'); return; }
        $orders = (new Order(new Database(require dirname(__DIR__, 2) . '/config/database.php')))->forUser((int)$user['id']);
        $this->view->render('shop/order_history', ['title'=>'Lịch sử đơn hàng','orders'=>$orders]);
    }

    public function add(string $id): void
    {
        Session::start();
        try {
            Csrf::verify($_POST['_csrf'] ?? null);
            $book = $this->books()->findById((int)$id);
            if (!$book || $book['status'] !== 'published') {
                throw new \RuntimeException('Sách không tồn tại hoặc chưa được bán.');
            }
            $cart = Session::get('cart', []);
            $current = (int)($cart[$id] ?? 0);
            if ($current + 1 > (int)$book['stock_quantity']) {
                throw new \RuntimeException('Số lượng vượt quá tồn kho.');
            }
            $cart[$id] = $current + 1;
            Session::put('cart', $cart);
            header('Location: /cart');
        } catch (Throwable $exception) {
            http_response_code(422);
            $this->view->render('shop/cart', ['title'=>'Giỏ hàng','error'=>$exception->getMessage(),'items'=>$this->cartItems()]);
        }
    }

    public function update(): void
    {
        Session::start();
        Csrf::verify($_POST['_csrf'] ?? null);
        $cart = Session::get('cart', []);
        if (isset($_POST['remove_id'])) {
            unset($cart[(string)(int)$_POST['remove_id']]);
            Session::put('cart', $cart);
            header('Location: /cart');
            return;
        }
        foreach ((array)($_POST['quantity'] ?? []) as $id => $quantity) {
            $book = $this->books()->findById((int)$id);
            $amount = max(0, (int)$quantity);
            if (!$book || $book['status'] !== 'published' || $amount === 0) {
                unset($cart[$id]);
                continue;
            }
            $cart[$id] = min($amount, (int)$book['stock_quantity']);
        }
        Session::put('cart', $cart);
        header('Location: /cart');
    }

    public function remove(string $id): void
    {
        Session::start();
        Csrf::verify($_POST['_csrf'] ?? null);
        $cart = Session::get('cart', []);
        unset($cart[$id]);
        Session::put('cart', $cart);
        header('Location: /cart');
    }
}
