<?php

declare(strict_types=1);

namespace App\Models;

use App\Core\Database;
use RuntimeException;

final class Order
{
    public function __construct(private Database $database)
    {
    }

    public function findByCode(string $orderCode): ?array
    {
        $statement = $this->database->connection()->prepare(
            'SELECT * FROM orders WHERE order_code = :order_code LIMIT 1'
        );
        $statement->execute(['order_code' => $orderCode]);
        $order = $statement->fetch();
        return $order ?: null;
    }

    public function createFromCart(int $userId, array $items, string $name, string $phone, string $address): string
    {
        $pdo = $this->database->connection();
        $pdo->beginTransaction();
        try {
            $subtotal = 0;
            $lockedItems = [];
            foreach ($items as $item) {
                $statement = $pdo->prepare('SELECT * FROM books WHERE id = :id AND status = :status FOR UPDATE');
                $statement->execute(['id' => (int)$item['book_id'], 'status' => 'published']);
                $book = $statement->fetch();
                $quantity = (int)$item['quantity'];
                if (!$book || $quantity < 1 || $quantity > (int)$book['stock_quantity']) {
                    throw new RuntimeException('Sách không đủ tồn kho để đặt hàng.');
                }
                $lineTotal = (int)$book['price'] * $quantity;
                $subtotal += $lineTotal;
                $lockedItems[] = ['book' => $book, 'quantity' => $quantity, 'line_total' => $lineTotal];
            }
            if ($lockedItems === []) {
                throw new RuntimeException('Giỏ hàng đang trống.');
            }

            $orderCode = 'MB' . date('ymdHis') . strtoupper(bin2hex(random_bytes(3)));
            $orderStatement = $pdo->prepare(
                'INSERT INTO orders (user_id, order_code, status, subtotal, shipping_fee, total, shipping_name, shipping_phone, shipping_address) '
                . 'VALUES (:user_id, :order_code, :status, :subtotal, :shipping_fee, :total, :shipping_name, :shipping_phone, :shipping_address)'
            );
            $orderStatement->execute([
                'user_id' => $userId, 'order_code' => $orderCode, 'status' => 'pending',
                'subtotal' => $subtotal, 'shipping_fee' => 0, 'total' => $subtotal,
                'shipping_name' => $name, 'shipping_phone' => $phone, 'shipping_address' => $address,
            ]);
            $orderId = (int)$pdo->lastInsertId();
            $itemStatement = $pdo->prepare(
                'INSERT INTO order_items (order_id, book_id, book_title, unit_price, quantity, line_total) '
                . 'VALUES (:order_id, :book_id, :book_title, :unit_price, :quantity, :line_total)'
            );
            $stockStatement = $pdo->prepare('UPDATE books SET stock_quantity = stock_quantity - :quantity WHERE id = :id');
            foreach ($lockedItems as $item) {
                $book = $item['book'];
                $itemStatement->execute([
                    'order_id' => $orderId, 'book_id' => $book['id'], 'book_title' => $book['title'],
                    'unit_price' => $book['price'], 'quantity' => $item['quantity'], 'line_total' => $item['line_total'],
                ]);
                $stockStatement->execute(['quantity' => $item['quantity'], 'id' => $book['id']]);
            }
            $pdo->commit();
            return $orderCode;
        } catch (\Throwable $exception) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            throw $exception;
        }
    }

    public function forUser(int $userId): array
    {
        $statement = $this->database->connection()->prepare(
            'SELECT * FROM orders WHERE user_id = :user_id ORDER BY created_at DESC'
        );
        $statement->execute(['user_id' => $userId]);
        return $statement->fetchAll();
    }

    public function allForAdmin(): array
    {
        return $this->database->connection()->query(
            'SELECT orders.*, users.name AS customer_name, users.email AS customer_email '
            . 'FROM orders INNER JOIN users ON users.id = orders.user_id ORDER BY orders.created_at DESC'
        )->fetchAll();
    }

    public function countAll(): int
    {
        return (int)$this->database->connection()->query('SELECT COUNT(*) FROM orders')->fetchColumn();
    }

    public function updateStatus(int $id, string $status): void
    {
        if (!in_array($status, ['pending', 'confirmed', 'shipping', 'completed', 'cancelled'], true)) {
            throw new RuntimeException('Trạng thái đơn hàng không hợp lệ.');
        }
        $statement = $this->database->connection()->prepare('UPDATE orders SET status = :status WHERE id = :id');
        $statement->execute(['status' => $status, 'id' => $id]);
    }
}
