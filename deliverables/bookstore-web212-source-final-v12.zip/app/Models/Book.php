<?php

declare(strict_types=1);

namespace App\Models;

use App\Core\Database;

final class Book
{
    public function __construct(private Database $database)
    {
    }

    public function findBySlug(string $slug): ?array
    {
        $statement = $this->database->connection()->prepare(
            'SELECT books.*, categories.name AS category_name FROM books '
            . 'INNER JOIN categories ON categories.id = books.category_id '
            . 'WHERE books.slug = :slug AND books.status = :status LIMIT 1'
        );
        $statement->execute(['slug' => $slug, 'status' => 'published']);
        $book = $statement->fetch();
        return $book ?: null;
    }

    public function published(): array
    {
        $statement = $this->database->connection()->prepare(
            'SELECT books.*, categories.name AS category_name FROM books '
            . 'INNER JOIN categories ON categories.id = books.category_id '
            . 'WHERE books.status = :status ORDER BY books.created_at DESC'
        );
        $statement->execute(['status' => 'published']);
        return $statement->fetchAll();
    }

    public function byCategory(string $categorySlug): array
    {
        $statement = $this->database->connection()->prepare(
            'SELECT books.*, categories.name AS category_name FROM books '
            . 'INNER JOIN categories ON categories.id = books.category_id '
            . 'WHERE categories.slug = :slug AND books.status = :status ORDER BY books.title'
        );
        $statement->execute(['slug' => $categorySlug, 'status' => 'published']);
        return $statement->fetchAll();
    }

    public function search(string $query): array
    {
        $statement = $this->database->connection()->prepare(
            'SELECT books.*, categories.name AS category_name FROM books '
            . 'INNER JOIN categories ON categories.id = books.category_id '
            . 'WHERE books.status = :status AND (books.title LIKE :title_query OR books.author LIKE :author_query) '
            . 'ORDER BY books.title'
        );
        $likeQuery = '%' . $query . '%';
        $statement->execute(['status' => 'published', 'title_query' => $likeQuery, 'author_query' => $likeQuery]);
        return $statement->fetchAll();
    }

    public function allForAdmin(): array
    {
        return $this->database->connection()->query(
            'SELECT books.*, categories.name AS category_name FROM books '
            . 'INNER JOIN categories ON categories.id = books.category_id ORDER BY books.id DESC'
        )->fetchAll();
    }

    public function countAll(): int
    {
        return (int)$this->database->connection()->query('SELECT COUNT(*) FROM books')->fetchColumn();
    }

    public function findById(int $id): ?array
    {
        $statement = $this->database->connection()->prepare('SELECT * FROM books WHERE id = :id LIMIT 1');
        $statement->execute(['id' => $id]);
        $book = $statement->fetch();
        return $book ?: null;
    }

    public function create(array $data): int
    {
        $statement = $this->database->connection()->prepare(
            'INSERT INTO books (category_id, title, slug, author, publisher, price, original_price, description, stock_quantity, status) '
            . 'VALUES (:category_id, :title, :slug, :author, :publisher, :price, :original_price, :description, :stock_quantity, :status)'
        );
        $statement->execute($data);
        return (int)$this->database->connection()->lastInsertId();
    }

    public function update(int $id, array $data): void
    {
        $data['id'] = $id;
        $statement = $this->database->connection()->prepare(
            'UPDATE books SET category_id = :category_id, title = :title, slug = :slug, author = :author, '
            . 'publisher = :publisher, price = :price, original_price = :original_price, description = :description, '
            . 'stock_quantity = :stock_quantity, status = :status WHERE id = :id'
        );
        $statement->execute($data);
    }

    public function delete(int $id): void
    {
        $statement = $this->database->connection()->prepare('DELETE FROM books WHERE id = :id');
        $statement->execute(['id' => $id]);
    }
}
