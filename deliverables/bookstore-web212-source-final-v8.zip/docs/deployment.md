# Hướng dẫn triển khai

## Local với Laragon

1. Đặt mã nguồn trong thư mục Laragon, ví dụ `C:\laragon\www`.
2. Đặt Apache DocumentRoot vào thư mục `public` của dự án.
3. Bật Apache trong Laragon.
4. Mở `http://localhost/`.
5. Kiểm tra route `/`, `/books` và `/khong-ton-tai`.

## Khởi tạo database

Trong MySQL Laragon, tạo database `bookstore_web212`, sau đó chạy lần lượt `database/schema.sql` và `database/seed.sql`. Không chạy lại seed trên production nếu chưa kiểm tra dữ liệu hiện có.

## Apache Shared Hosting/cPanel

- Nếu hosting cho phép, đặt DocumentRoot vào thư mục `public/`.
- Nếu không đổi được DocumentRoot, phải lập phương án triển khai riêng và kiểm tra lại quyền truy cập trước khi dùng; không tự ý chuyển toàn bộ thư mục nội bộ ra public.
- Bật URL rewriting và giữ `.htaccess` trong `public/`.
- Không upload `.env` thật, credential, log hoặc thư mục dependency không cần thiết.
- Cấu hình PHP 8.x và tạo database riêng ở giai đoạn chức năng.

## Tạo Admin demo

Không có mật khẩu Admin mặc định trong mã nguồn. Sau khi tạo database, chạy lệnh tại thư mục project:

```text
php tools/create_admin.php
```

Nhập tên, email và mật khẩu riêng cho môi trường demo. Không commit credential vào Git và không dùng mật khẩu demo ở production.

## Chưa thực hiện

Chưa deploy hosting thật và chưa có Live URL. SQL đã có trong `database/schema.sql` và `database/seed.sql`; tài khoản Admin demo chỉ tồn tại trong database local, không lưu mật khẩu trong mã nguồn.
